﻿--------------------------------------------------------------------------------------
ARCHIVOS QUE SE ENTREGAN:
--------------------------------------------------------------------------------------
MEMORIA:
-Archivo de explicación del trabajo realizado
--------------------------------------------------------------------------------------
PROLOG:
-newEXE.pl: archivo prolog con interfaz de terminal y optimización
-newEXEsocket.pl: archivo prolog con interfaz JAVA y optimización
-exe.pl: archivo prolog con interfaz de terminal y con preguntas secuenciales fijas
-exesocket.pl: archivo prolog con interfaz JAVAl y con preguntas secuenciales fijas
-knoledge_base.pl: base de conocimiento dinámica
-preguntas.pl: base de conocimiento estática
--------------------------------------------------------------------------------------
JAVA:
-proyecto abrir con netbeans 
-------------------------------------------------------------------------------------
